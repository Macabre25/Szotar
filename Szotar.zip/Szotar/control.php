<?php
    session_start();
    require_once 'Const.php';
   require_once 'connect.php';
   
   
   
 $event = filter_input(INPUT_POST, "event", FILTER_SANITIZE_SPECIAL_CHARS);
    $Rosz = filter_input(INPUT_POST, "rosz", FILTER_SANITIZE_SPECIAL_CHARS);
       $Jo = filter_input(INPUT_POST, "jo", FILTER_SANITIZE_SPECIAL_CHARS);
    $szokereses = filter_input(INPUT_POST, "keresett", FILTER_SANITIZE_SPECIAL_CHARS);
    $magyar = filter_input(INPUT_POST, "magyar", FILTER_SANITIZE_SPECIAL_CHARS);
    $angol = filter_input(INPUT_POST, "angol", FILTER_SANITIZE_SPECIAL_CHARS);
   $magyarSzo = filter_input(INPUT_POST, "magyarSzo", FILTER_SANITIZE_SPECIAL_CHARS);
    $angolSzo = filter_input(INPUT_POST, "angolSzo", FILTER_SANITIZE_SPECIAL_CHARS);
    $szotarId = filter_input(INPUT_GET, "szid", FILTER_SANITIZE_NUMBER_INT);
    settype($szotarId, "integer");
   

  
    
    //felvitel
 if ($event === "Szotarfelvitel") 
 {
      $angol= str_replace(MIT, MIRE, $db);
      $magyar= str_replace(MIT, MIRE, $db);
    $sql = "SELECT count(*) as db FROM szavak  WHERE angolSzo='$angol' AND magyarSzo='$magyar' ";
      $tabla = mysqli_query($dbc, $sql);
     
      list($db) = mysqli_fetch_row($tabla);
     
     
      if ($db > 0) {
       $Rosz=  "Ez a szópár már fent van!";        
       
     } else {
        
   $sql = "INSERT INTO szavak (szotarId, angolSzo, magyarSzo) VALUES ($szotarId, '$angol', '$magyar')";
            mysqli_query($dbc,$sql);
            $szotarId = mysqli_insert_id($dbc);
         $Jo= 'A szópár fel van véve!';  
         }
     
 }
      
//keresés
 if (pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME) == "index") {
    
    $sql = "SELECT angolSzo,magyarSzo FROM szavak WHERE  angolSzo like '%$szokereses%' or magyarSzo like '%$szokereses%'";  
    $result = mysqli_query($dbc, $sql);
    $resultT = mysqli_query($dbc, $sql);
 }

if ($event === "letöltes") { 
    
  $file = fopen("Szópár.txt", "a");
   $sql = "SELECT * From szavak";
    $result = mysqli_query($dbc, $sql);
  while($row = mysqli_fetch_assoc($result))
{ 
      $mail = "\n";
     $empty="-";
    fwrite( $file ,$row["magyarSzo"]);
     fwrite( $file ,$empty);
   fwrite( $file ,$row["angolSzo"]);
   fwrite( $file ,$mail);
}
fclose($file);        
   }               
?>

     