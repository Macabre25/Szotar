<?php include_once 'control.php'; ?>
<!DOCTYPE html>
<html lang="hu">

        <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
     <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    </head>
    <html>
        <body class="bg-success">
          <h1 class="text-center">Magyar-Angol szótár</h1>
            