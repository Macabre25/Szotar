<?php

  $dbc = mysqli_connect(HOST,DB_USER,DB_PASS,DB_NAME);
    $sql = "set names utf8";
    mysqli_query($dbc, $sql)
             
      
            ?>

