<?php include_once 'header.php';?>
      <div>
            <h3 class="text-center" >Keresett szó: <?php echo $szokereses; ?></h3>  
            <h1 class="text-center">Keresés</h1>
                    <div class="card-body">
                       <div class="container text-center " style="width:200px;" >
                      <div class="form-group"> 
                          <form action="index.php" method="post">
                                <input type="text" class="form-control" name="keresett"  placeholder="Keresett szó" >
                                <input type="hidden" name="event"  value="kereses">
                                <button  class="btn btn-success">Keresés</button>
                          </form>
                </div>
                      </div>
            
                  </div> 
    
    
           
      <div  class="container">
            <div class="grid" data-masonry='{"itemSelector": ".grid-item"}' >
                <div class="col-11 col-sm-7 col-lg-6 grid-item " >
                       <h1 class="text-center">Magyar fórdítás</h1>
                <p  class="text-center">  <?php 
                if (mysqli_num_rows($result) > 0 ) {
                    while($row = mysqli_fetch_assoc($result)) {
                    echo $magyarSzo= $row["magyarSzo"]. "<br>";
                  }

                 } 
                 else
                 {
                    echo "Nincs ilyen szó az adatbázisban";
                 }                   ?>
                </p>   
                </div>
                     <div  class="col-11 col-sm-10 col-lg-6 grid-item ">
                 <h1 class="text-center" >Angol fórdítás</h1>
                 <p class="text-center" >
              <?php 
                  if (mysqli_num_rows($resultT) > 0) {
                      while($row = mysqli_fetch_assoc($resultT)) {
                       echo  $angolSzo=  $row["angolSzo"]. "<br>";
                    } 
                }
                else 
                {
                 echo "Nincs ilyen szó az adatbázisban";
                }  
                ?></p>
      
        </div>
                    </div>
                </div>
          
        
            <div>
            <h1 class="text-center">Szópár felvitel</h1>
           
                  <div class="card-body  ">
                    <h5 class="text-center">
              <?php echo $Rosz; echo $Jo; ?>
            </h5>
                      <div class="container text-center " style="width:200px;" >
                    <form action="index.php" method="post">    
                   <input class="form-control" type="text" name="angol" placeholder="Angol szó" value="<?php echo $angol; ?> "required autofocus ">
                    
                   <input class="form-control" type="text" name="magyar" placeholder="Magyar szó" value="<?php echo $magyar; ?>" required autofocus ">
                    
                    <input type="hidden" name="event" value="Szotarfelvitel" >
                        <button class="btn btn-success">Szópár felvitel</button>
                  </form> 
                      </div> 
                </div>
               </div>
            <div class="continer" > 
                     <h1 class="text-center">Szópárok   mentés</h1>
                 <form  method="post"> 
                      <input type="hidden" name="event" value="letöltes" >
                      <button class="btn btn-success" style="margin-left: 830px;">Mentés</button>
                 </form> 
                  </div> 
    <?php include_once 'footer.php'; ?>