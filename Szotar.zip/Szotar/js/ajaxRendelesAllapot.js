function ajaxRendelesAllapot(rfid) {
    $.ajax({
        url: "control.php",
        type: "post",
        data: {
            "event": "rAllapotValtozas",
            "rfid": rfid
        },
        success: function () {
            if ($("#allapotCella" + rfid).html() === "várakozik") {
                $("#allapotCella" + rfid).html("kiszállítva");
                $("#ikon" + rfid).attr("class", "glyphicon glyphicon-time");
                $("#sor" + rfid).attr("class", "");
            } else {
                $("#allapotCella" + rfid).html("várakozik");
                $("#ikon" + rfid).attr("class", "glyphicon glyphicon-ok");
                $("#sor" + rfid).attr("class", "text-danger");
            }
        }
    });
}
